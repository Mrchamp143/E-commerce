﻿using System;

namespace FoodOrderingEcomm
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Any logic needed during page load
        }

        protected void SignUp_Click(object sender, EventArgs e)
        {
            // Logic for signing up the user
            // Save data to the database or session if needed

            // Redirect to Home.aspx
            Response.Redirect("Home.aspx");
        }
    }
}
