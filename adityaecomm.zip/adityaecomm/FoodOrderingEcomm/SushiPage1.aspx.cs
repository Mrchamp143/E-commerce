﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FoodOrderingEcomm
{
    public partial class SushiPage1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize cart if not already done
            if (Session["Cart"] == null)
            {
                Session["Cart"] = new List<string>();
            }
        }

        protected void AddToCart_Click(object sender, EventArgs e)
        {
            // Get the button that triggered the event
            var button = (System.Web.UI.WebControls.Button)sender;

            // Get product details from CommandArgument
            string productDetails = button.CommandArgument;

            // Add product details to the cart
            var cart = (List<string>)Session["Cart"];
            cart.Add(productDetails);

            // Store updated cart back in session
            Session["Cart"] = cart;

            // Optional: Show a message or redirect to cart page
            Response.Write("<script>alert('Product added to cart!');</script>");
        }
    }
}