﻿using System;
using System.Data.SqlClient;

namespace FoodOrderingEcomm
{
    public partial class PizzaPage : System.Web.UI.Page
    {
        private readonly string connectionString = @"Data Source=localhost\SQLExpress;Initial Catalog=PizzaOrderingSystem;Integrated Security=True;Pooling=False";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialization logic, if any
        }

        protected void AddToCartButton_Click(object sender, EventArgs e)
        {
            var button = sender as System.Web.UI.WebControls.Button;
            if (button == null)
            {
                ShowMessage("Error: Could not identify the button.");
                return;
            }

            string pizzaID = button.CommandArgument;

            string pizzaName = string.Empty;
            string pizzaPrice = string.Empty;
            string pizzaImageURL = string.Empty;

            // Map pizza IDs to hidden fields
            if (pizzaID == "101")
            {
                pizzaName = HiddenPizzaName101.Value;
                pizzaPrice = HiddenPizzaPrice101.Value;
                pizzaImageURL = HiddenPizzaImageURL101.Value;
            }
            else if (pizzaID == "102")
            {
                pizzaName = HiddenPizzaName102.Value;
                pizzaPrice = HiddenPizzaPrice102.Value;
                pizzaImageURL = HiddenPizzaImageURL102.Value;
            }
            else
            {
                ShowMessage("Error: Invalid pizza ID.");
                return;
            }

            // Manage database operations
            ManagePizzaInCart(pizzaID, pizzaName, pizzaPrice, pizzaImageURL);
        }

        private void ManagePizzaInCart(string pizzaID, string pizzaName, string pizzaPrice, string pizzaImageURL)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Delete existing pizza record if it exists
                    string deleteQuery = "DELETE FROM Cart WHERE PizzaID = @PizzaID";
                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                    {
                        deleteCommand.Parameters.AddWithValue("@PizzaID", pizzaID);
                        deleteCommand.ExecuteNonQuery();
                    }

                    // Insert the new pizza record into the cart
                    string insertQuery = "INSERT INTO Cart (PizzaID, Name, Price, ImageURL) VALUES (@PizzaID, @Name, @Price, @ImageURL)";
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@PizzaID", pizzaID);
                        insertCommand.Parameters.AddWithValue("@Name", pizzaName);
                        insertCommand.Parameters.AddWithValue("@Price", decimal.Parse(pizzaPrice));
                        insertCommand.Parameters.AddWithValue("@ImageURL", pizzaImageURL);

                        int rowsAffected = insertCommand.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            ShowMessage("Pizza successfully added to the cart.");
                        }
                        else
                        {
                            ShowMessage("Failed to add pizza to the cart.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ShowMessage("An error occurred: " + ex.Message);
                }
            }
        }

        private void ShowMessage(string message)
        {
            // You can improve this to display the message in a label or via JavaScript alerts
            Response.Write("<script>alert('" + message.Replace("'", "\\'") + "');</script>");
        }
    }
}
